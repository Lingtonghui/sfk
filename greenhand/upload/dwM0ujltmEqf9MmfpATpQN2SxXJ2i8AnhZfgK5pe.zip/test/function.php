<?php

$xx = name( 100,200 );

var_dump($xx);

function name( $nn, $yy ){
	$cc = $nn+$yy;
	return 123;
}



?>