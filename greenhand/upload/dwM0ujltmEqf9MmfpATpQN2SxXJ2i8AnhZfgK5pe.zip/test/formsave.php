<?php

$arr = [1,2,3];

echo $arr['a'];