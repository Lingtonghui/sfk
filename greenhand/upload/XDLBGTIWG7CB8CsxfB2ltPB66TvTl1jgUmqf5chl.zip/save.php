<?php

include('input.php');

$content = $_POST['content'];
$user = $_POST['user'];


$input = new input();


//调用函数，检查留言内容
$is = $input->post( $content );
if( $is == false ){
	die('留言内容的数据不正确');
}

//调用函数，检查留言人
$is = $input->post( $user );
if( $is == false ){
	die('留言人的数据不正确');
}
var_dump( $content, $user );


?>